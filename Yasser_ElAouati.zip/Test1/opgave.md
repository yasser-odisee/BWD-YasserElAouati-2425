# Praktijkdeel: HTML

Maak aan de hand van de bijgeleverde screenshots de index en contact HTML pagina:
- hou je aan de technieken en praktijken gezien in de cursus
- let op layout, validatie en linting!
- voor de Google map kies je een willekeurig adres in de VS
- van de links die niet gekend zijn, mag de href leeglaten, maar waar je kan moet het ingevuld zijn
- voeg ook structurele elementen als header, footer, section, nav enz... toe
- voeg geen onnodige div's, id- of class-attributen toe; dit is enkel een oefening op HTML, niet op CSS!

We verwachten enkel de HTML; je hoeft de pagina dus **niet op te maken met CSS!**

LET OP: 
- je mag gebruik maken van het internet, de cursus, eigen code en alle A.I. tools
- je mag GEEN gebruik maken van tools/apps/programma's die het delen van code mogelijk maken (OneDrive, Discord, mail, sociale media...) op straffe van een fraudedossier 
